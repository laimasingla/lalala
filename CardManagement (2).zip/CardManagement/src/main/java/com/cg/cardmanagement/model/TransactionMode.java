
package com.cg.cardmanagement.model;

public enum TransactionMode {


	ONLINE, CARD,CASH;
}

