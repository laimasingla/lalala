package com.cg.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.Transaction;

public interface DebitCardTransactionDao {
	//List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber) throws IBSException;

	

	BigInteger getDebitCardNumber(BigInteger transactionId) throws IBSException;

	BigInteger getDMUci(BigInteger transactionId) throws IBSException;

	boolean verifyDebitTransactionId(BigInteger transactionId) throws IBSException;



	BigInteger getDebitMismatchTranscId(String queryId) throws IBSException;



	Transaction getDebitMismatchTransc(BigInteger mismatchTransactionId) throws IBSException;



	List<Transaction> getDebitTrans(LocalDate startDate, LocalDate endDate, BigInteger debitCardNumber) throws IBSException;

	boolean checkTransactions(BigInteger debitCardNumber) throws IBSException;
}
