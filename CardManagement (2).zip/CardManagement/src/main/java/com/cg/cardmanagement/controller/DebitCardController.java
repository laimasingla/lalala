package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.Transaction;
import com.cg.cardmanagement.service.DebitCustomer;
import com.cg.cardmanagement.service.DebitCustomerVerification;

@RestController
@Scope("session")
@RequestMapping("/debit")
public class DebitCardController {

	@Autowired
	private DebitCustomer debitService;
	@Autowired
	private DebitCustomerVerification debitVerify;

	@GetMapping("/debitlist")
	public ResponseEntity<List<Object[]>> list() throws IBSException {
		// List<DebitCardBean>debitCardBeans = debitService.viewAllDebitCards();
		List<Object[]> debitCardBeansSorted = debitService.viewAllSortedDebitCards();

		return new ResponseEntity<List<Object[]>>(debitCardBeansSorted, HttpStatus.OK);
	}

	@GetMapping("/carddisplaymenu/{cardNumber}")
	public ResponseEntity<Object> cardDetails(@PathVariable("cardNumber") BigInteger cardNumber) throws IBSException {
		Object object = debitService.fetchDebitdetails(cardNumber);

		return new ResponseEntity<Object>(object, HttpStatus.OK);
	}

	
	
	
	@PatchMapping(value = "/block/{cardNumber}/{pin}")
	public ResponseEntity<String> block(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";
		if (debitVerify.verifyDebitCardPin(pin)) {
			if (!debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					debitService.requestDebitCardLost(cardNumber);
					output = " Your card has been Blocked. Contact branch for further process!";
				} else {
					output = "Card number and pin don't match!! Try again!";
				}
			} else {

				output = "Card already blocked";
			}
		} else {
			output = "Invalid pin format";

		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * @PostMapping(value = "/block") public ResponseEntity<String>
	 * block(@PathVariable("cardNumber") BigInteger cardNumber,
	 * 
	 * @PathVariable("pin") String pin) throws IBSException { String output = ""; if
	 * (debitVerify.verifyDebitCardPin(pin)) { if
	 * (!debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")) {
	 * if (debitVerify.verifyDebitPin(pin, cardNumber)) {
	 * debitService.requestDebitCardLost(cardNumber); output =
	 * " Your card has been Blocked. Contact branch for further process!"; } else {
	 * output = "Card number and pin don't match!! Try again!"; } } else {
	 * 
	 * output = "Card already blocked"; } } else { output = "Invalid pin format";
	 * 
	 * } return new ResponseEntity<String>(output, HttpStatus.OK);
	 * 
	 * }
	 */

	@PatchMapping(value = "/activate/{cardNumber}/{pin}")
	public ResponseEntity<String> activate(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";
		if (debitVerify.verifyDebitCardPin(pin)) {
			if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					debitService.activateDebitCard(cardNumber);
					output = "Card successfully activated!";
				} else {
					output = "Card number and pin don't match!! Try again!";
				}
			} else {

				String status = debitService.getDebitcardStatus(cardNumber);
				output = "Card already " + status;
			}

		} else {
			output = "Invalid pin format";

		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/deactivate/{cardNumber}/{pin}")
	public ResponseEntity<String> deactivate(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";

		if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {
			if (debitVerify.verifyDebitCardPin(pin)) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {

					debitService.deactivateDebitCard(cardNumber);
					output = "Card successfully deactivated!";
				} else {
					output = "Card number and pin don't match!! Try again!";
				}
			} else {
				output = "Invalid pin format";

			}
		} else {
			String status = debitService.getDebitcardStatus(cardNumber);
			output = "Card already " + status;

		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/resetpin/{cardNumber}/{newpin}/{newpin2}/{pin}")
	public ResponseEntity<String> resetPin2(@PathVariable("cardNumber") BigInteger cardNumber,
			@PathVariable("newpin") String newpin, @PathVariable("newpin2") String newpin2,
			@PathVariable("pin") String pin) throws IBSException {
		String output = "";

		if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {
			if (debitVerify.verifyDebitCardPin(pin)) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					if (debitVerify.verifyDebitCardPin(newpin))

						if (newpin2.equals(newpin)) {
							debitService.resetDebitPin(cardNumber, newpin);
							output = "PIN SUCCESSFULLY CHANGED";
						} else {
							output = "PINS DO NOT MATCH!! TRY AGAIN";
						}
					return new ResponseEntity<String>(output, HttpStatus.OK);

				} else {
					output = "Card number and pin don't match!! Try again!";

				}

			} else {

				output = "Invalid pin format";

			}
		} else {
			String status = debitService.getDebitcardStatus(cardNumber);
			output = "Your Card is " + status + ". Cannot change pin!";
		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@PostMapping(value = "/upgrade")
	public ResponseEntity<String> upgrade(@RequestBody CaseIdBean caseIdBean) throws IBSException {

		String type = caseIdBean.getDefineServiceRequest();
		BigInteger cardNumber = caseIdBean.getCardNumber();
		String remarks = caseIdBean.getCustomerRemarks();

		String output = "";

		if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {

			String initialType = debitService.getDebitcardType(cardNumber);
			if (initialType.equalsIgnoreCase("Silver")) {
				if (type.equalsIgnoreCase("Gold") || type.equalsIgnoreCase("Platinum")) {
					String num = debitService.requestDebitCardUpgrade(cardNumber, type, remarks);
					output = "Ticket Raised successfully. Your reference Id is" + num;

				} else {

					output = "you can only upgrade to Gold/platinum";
				}

			} else

			if (initialType.equalsIgnoreCase("Gold")) {

				if (type.equalsIgnoreCase("Platinum")) {
					String num = debitService.requestDebitCardUpgrade(cardNumber, type, remarks);
					output = "Ticket Raised successfully. Your reference Id is" + num;

				} else {

					output = "you can only upgrade to Platinum";
				}

			}

			else

			if (initialType.equalsIgnoreCase("Platinum")) {

				output = "Highest level .Cannot upgrade any further";

			} else {

				output = "Invalid Card Type";
			}

		} else {
			String cardStatus = debitService.getDebitcardStatus(cardNumber);
			output = "Cannot upgrade" + cardStatus + " card";
		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@GetMapping(value = "/requestStatement/{cardNumber}/{fromdate}/{enddate}")
	public ResponseEntity<List<Transaction>> requestStatement(

			@PathVariable("cardNumber") BigInteger cardNumber, @PathVariable("fromdate") String fromdate,
			@PathVariable("enddate") String enddate) throws IBSException {

		DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;

		LocalDate startDate1 = LocalDate.parse(fromdate, formatter);
		LocalDate endDate1 = LocalDate.parse(enddate, formatter);
		List<Transaction> bean1 = debitService.getDebitTransactions(startDate1, endDate1, cardNumber);
		return new ResponseEntity<List<Transaction>>(bean1, HttpStatus.OK);

	}

	@GetMapping(value = "/mismatchDebit/{transactionId}/{remarks}")
	public ResponseEntity<String> debitMismatch(@PathVariable("transactionId") BigInteger transactionId,
			@PathVariable("remarks") String remarks) throws IBSException {

		String refId = debitService.raiseDebitMismatchTicket(transactionId, remarks);
		String output = " Ticket raised successfully. your reference ID is " + refId;
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@GetMapping(value = "/applynewdebit/{accNum}/{type}")
	public ResponseEntity<String> applyNewDebitCard2(@PathVariable("accNum") BigInteger accountNumber,
			@PathVariable("type") String type) throws IBSException {
		String output = "";

		if (debitService.checkDebitCardCount()) {
System.out.println("a");
			String num = debitService.applyNewDebitCard(accountNumber, type);
			output = "Ticket Raised successfully. Your reference Id is" + num;
		} else {
			output = "You already have 3  debit cards.";

		}
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@ExceptionHandler
	public ResponseEntity<String> ibsException(IBSException e) {

		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}
}
