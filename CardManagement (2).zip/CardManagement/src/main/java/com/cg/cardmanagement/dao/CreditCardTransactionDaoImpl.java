package com.cg.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.cardmanagement.exception.ErrorMessages;
import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CreditCardTransaction;

@Repository
public class CreditCardTransactionDaoImpl implements CreditCardTransactionDao {

	//private static Logger logger = Logger.getLogger(CreditCardTransactionDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;

	
	@Override

	public boolean verifyCreditTransactionId(BigInteger transactionId) throws IBSException {
		//logger.info("entered into viewAllCreditCards method of CreditCardDaoImpl class");

		CreditCardTransaction d = null;
		boolean result = false;
		try {
			d = entityManager.find(CreditCardTransaction.class, transactionId);
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.INVALID_TRANSACTION_ID_MESSAGE);
		}
		if (d != null) {
			result = true;
		}

		return result;

	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(LocalDate startDate, LocalDate endDate,
			BigInteger creditCardNumber) throws IBSException {
		//logger.info("entered into getCreditCards method of CreditCardDaoImpl class");
		List<CreditCardTransaction> creditTransList = null;
		LocalDateTime startDate1 = startDate.atTime(LocalTime.now());
		LocalDateTime endDate1 = endDate.atTime(LocalTime.now());
		try {

			TypedQuery<CreditCardTransaction> query = entityManager.createQuery(
					"Select d from CreditCardTransaction d JOIN d.creditBeanObject c WHERE d.dateOfTran BETWEEN :start and :end AND c.cardNumber=:cardNum ",
					CreditCardTransaction.class);
			query.setParameter("start", startDate1);
			query.setParameter("end", endDate1);
			query.setParameter("cardNum", creditCardNumber);
			creditTransList = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
		}
		return creditTransList;
	}

	@Override
	public BigInteger getCreditCardNumber(BigInteger transactionID) throws IBSException {

		BigInteger creditCardNumber = null;
		try {
			//logger.info("entered into getCreditCardNumber method of CreditCardDaoImpl class");
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"Select c.cardNumber from CreditCardTransaction d join d.creditBeanObject c where d.transactionId=:transactionId",
					BigInteger.class);
			query.setParameter("transactionId", transactionID);

			creditCardNumber = query.getSingleResult();
		}

		catch (NoResultException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}

		return creditCardNumber;
	}

	@Override
	public BigInteger getCMUci(BigInteger transactionID) throws IBSException {
		//logger.info("entered into getCMUci method of CreditCardDaoImpl class");
		BigInteger uci = null;
		try {

			TypedQuery<BigInteger> query = entityManager.createQuery(
					"Select d.UCI from CreditCardTransaction d where d.transactionId=:transactionId", BigInteger.class);
			query.setParameter("transactionId", transactionID);
			uci = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.TRANS_NOT_EXIST_MESSAGE);
		}
		return uci;
	}

	@Override
	public BigInteger getCreditMismatchTranscId(String queryId) throws IBSException {
		BigInteger transcId = null;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"Select d.defineServiceRequest from CaseIdBean d  WHERE d.caseIdTotal =:QueryId ", String.class);
			query.setParameter("QueryId", queryId);
			transcId = new BigInteger(query.getSingleResult());
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.TRANS_NOT_EXIST_MESSAGE);
		}
		return transcId;
	}

	@Override
	public CreditCardTransaction getCreditMismatchTransc(BigInteger transactionId) throws IBSException {
		CreditCardTransaction creditTransactionList = null;
		try {
			TypedQuery<CreditCardTransaction> query = entityManager.createQuery(
					"Select d from CreditCardTransaction d WHERE d.transactionId =:TransactionId ",
					CreditCardTransaction.class);
			query.setParameter("TransactionId", transactionId);
			creditTransactionList = query.getSingleResult();

		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.TRANS_NOT_EXIST_MESSAGE);
		}
		return creditTransactionList;
	}

	@Override
	public boolean checkTransactions(BigInteger creditCardNumber) throws IBSException {
		boolean result = false;

		try {
			TypedQuery<CreditCardTransaction> query = entityManager.createQuery(
					"Select d from CreditCardTransaction d JOIN d.creditBeanObject c WHERE c.cardNumber=:cardNum ",
					CreditCardTransaction.class);

			query.setParameter("cardNum", creditCardNumber);
			List<CreditCardTransaction> creditCards = query.getResultList();
			if (creditCards.size() > 0) {
				result = true;
			}
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
		}

		return result;
	}

}
