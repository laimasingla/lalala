package com.cg.cardmanagement.service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CreditCardBean;
import com.cg.cardmanagement.model.CreditCardTransaction;

public interface CreditCustomer {

	public List<CreditCardBean> viewAllCreditCards() throws IBSException;

	void resetCreditPin(BigInteger creditCardNumber, String pin) throws IBSException;

	

	void requestCreditCardLost(BigInteger creditCardNumber) throws IBSException;

	String raiseCreditMismatchTicket(BigInteger transactionId, String remarks) throws IBSException;

	//public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException;

	List<CreditCardBean> getUnblockedCreditCards() throws IBSException;

	

	void deactivateCreditCard(BigInteger creditCardNumber) throws IBSException;

	public void activateCreditCard(BigInteger creditCardNumber) throws IBSException;

	public List<CreditCardBean> getInactiveCreditCards() throws IBSException;

	String addToServiceRequestTable(String caseIdGenOne);

	public List<CreditCardTransaction> getCreditTrans(LocalDate startDate1, LocalDate endDate1,
			BigInteger creditCardNumber) throws IBSException;

	public boolean getCreditTransactions(BigInteger creditCardNumber)throws IBSException;

	public boolean checkCreditCardCount() throws IBSException;

	String applyNewCreditCard(String newCardType, BigInteger uci) throws IBSException;

	String requestCreditCardUpgrade(BigInteger creditCardNumber, String type, String remarks) throws IBSException;

	public Object fetchCreditdetails(BigInteger creditCard) throws IBSException;

	public String getCreditcardStatus(BigInteger creditCard)throws IBSException;

	public String getCreditcardType(BigInteger creditCard)throws IBSException;

	public List<Object[]> viewAllSortedCreditCards() throws IBSException;



}
