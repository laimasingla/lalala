package com.cg.cardmanagement.model;

public enum TransactionType {
	CREDIT, DEBIT;

}
