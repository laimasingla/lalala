package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface DebitCustomer {

	public List<DebitCardBean> viewAllDebitCards() throws IBSException;

	String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice) throws IBSException;

	void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException;

	String getDebitcardType(BigInteger debitCardNumber) throws IBSException;

	String applyNewDebitCard(BigInteger accountNumber, String newCardType) throws IBSException;

	void requestDebitCardLost(BigInteger debitCardNumber) throws IBSException;

	String raiseDebitMismatchTicket(BigInteger transactionId, String remarks) throws IBSException;

	public List<DebitCardTransaction> getDebitTransactions(int dys, BigInteger debitCardNumber) throws IBSException;

	public List<DebitCardBean> getUnblockedDebitCards() throws IBSException;

	public List<AccountBean> getAccountList() throws IBSException;

	public boolean checkDebitCardCount() throws IBSException;

	void deactivateDebitCard(BigInteger debitCardNumber) throws IBSException;

	public void activateDebitCard(BigInteger debitCardNumber) throws IBSException;

	public List<DebitCardBean> getInactiveDebitCards() throws IBSException;

	String addToServiceRequestTable(String caseIdGenOne);
}
