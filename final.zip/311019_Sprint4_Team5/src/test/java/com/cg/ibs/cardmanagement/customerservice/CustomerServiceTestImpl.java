package com.cg.ibs.cardmanagement.customerservice;

//import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.CustomerService;
import com.cg.ibs.cardmanagement.service.CustomerServiceImpl;

public class CustomerServiceTestImpl {

	CustomerService customerService = new CustomerServiceImpl();
	CustomerDao dao = new CustomerDaoImpl();

	@Test
	public void getNewCardType() {
		int newCardType = 1;
		try {
			assertEquals("Platinum", customerService.getNewCardtype(newCardType));
		} catch (IBSException e) {
			fail(e.getMessage());
		}
	}

	@Test
	public void getInvalidNewCardType() {
		int newCardType = 1;
		try {
			assertNotEquals("Silver", customerService.getNewCardtype(newCardType));
		} catch (IBSException e) {
			fail(e.getMessage());
		}
	}

@Test
public void generateCaseId() {
	String caseOne="ANDC";
	
		assertNotNull(customerService.addToServiceRequestTable(caseOne));
		
}

   @Test
	public void getPinLength() {
	   String pin="4321";
	   try {
	   assertEquals(4,customerService.getPinLength(pin));
	   }
	   catch(IBSException e) {
		   fail(e.getMessage());
	   }
   }
   
   @Test
	public void getInvalidPinLength() {
	   String pin="432";
	   Assertions.assertThrows(IBSException.class, () -> {
           customerService.getPinLength(pin);
       });
  }
   
   @Test
   public void viewServiceRequestStatus() {
	   String custRefId="RDCL191031113722896";
	   Assertions.assertThrows(IBSException.class, () -> {
           customerService.viewServiceRequestStatus(custRefId);
       });
   }
   
   @Test
   public void checkMyChoice() {
	   int myChoice=1;
	   try {
	   assertEquals("Gold", customerService.checkMyChoice(myChoice));
	   }
	   catch(IBSException e) {
		   fail(e.getMessage());
	   }
   }
   
   
   @Test
   public void InvalidcheckMyChoice() {
	   int myChoice=3;
	   Assertions.assertThrows(IBSException.class, () -> {
           customerService.checkMyChoice(myChoice);
       });
   }
   
   @Test
	void checkInvalidNoOfDays() {
		int days = 1000;
		Assertions.assertThrows(IBSException.class, () -> {
			customerService.checkDays(days);
		});

	}
   
   @Test
   public void checkMyChoiceGold() {
	   int myChoice=2;
	   try {
	   assertEquals("Platinum", customerService.checkMyChoiceGold(myChoice));
	   }
	   catch(IBSException e) {
		   fail(e.getMessage());
	   }
   }
   
   
   @Test
   
   public void InvalidcheckMyChoiceGold() {
	   int myChoice=3;
	   Assertions.assertThrows(IBSException.class, () -> {
           customerService.checkMyChoiceGold(myChoice);
       });
   }
   
   
	 
}


	





	


	

	
	


	
		
		
		

		
		
			
		
		
		
		
	
	
