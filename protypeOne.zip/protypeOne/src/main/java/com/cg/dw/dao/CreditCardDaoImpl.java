package com.cg.dw.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.model.CreditCardBean;

@Repository
public class CreditCardDaoImpl implements CreditCardDao {
	//private static Logger logger = Logger.getLogger(CreditCardDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	
	public List<CreditCardBean> viewAllCreditCards() throws IBSException {
		//logger.info("entered into viewAllCreditCards method of CreditCardDaoImpl class");
		List<CreditCardBean> creditCards = null;

		try {
			TypedQuery<CreditCardBean> creditQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_CREDIT_CARD,
					CreditCardBean.class);
			creditCards = creditQuery.getResultList();
		} catch (NoResultException e) {

			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}

		return creditCards;

	}

	@Override
	public void setNewCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
		//logger.info("entered into setNewCreditPin method of CreditCardDaoImpl class");
		CreditCardBean cardBean = null;
		try {
			cardBean = entityManager.find(CreditCardBean.class, creditCardNumber);
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
		cardBean.setCurrentPin(newPin);

	}

	@Override
	public String getCreditCardPin(BigInteger creditCardNumber) throws IBSException {
		//logger.info("entered into getCreditCardPin method of CreditCardDaoImpl class");

		TypedQuery<String> query = entityManager
				.createQuery("select c.currentPin from CreditCardBean c where cardNumber=:creditCardNum", String.class);
		query.setParameter("creditCardNum", creditCardNumber);
		String pin = null;
		try {
			pin = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
		return pin;
	}

	@Override
	public BigInteger getCreditUci(BigInteger creditCardNumber) throws IBSException {
		//logger.info("entered into getCreditUci method of CreditCardDaoImpl class");
		BigInteger uci = null;
		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"select d.UCI from CreditCardBean c join  c. customerBeanObject d where c.cardNumber=:creditCardNum",
					BigInteger.class);
			query.setParameter("creditCardNum", creditCardNumber);
			uci = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
		return uci;

	}

	@Override
	public String getcreditCardType(BigInteger creditCardNumber) throws IBSException {
		//logger.info("entered into getCreditCardType method of CreditCardDaoImpl class");
		TypedQuery<String> query = entityManager
				.createQuery("select c.cardType from CreditCardBean c where c.cardNumber=:creditCardNum", String.class);
		query.setParameter("creditCardNum", creditCardNumber);

		String type = null;
		try {
			type = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
		return type;
	}

	@Override
	public String getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
		//logger.info("entered into getCreditCardStatus method of CreditCardDaoImpl class");
		TypedQuery<String> query = entityManager.createQuery(
				"select d.cardStatus from CreditCardBean d where d.cardNumber=:creditCardNum", String.class);
		query.setParameter("creditCardNum", creditCardNumber);
		String status = null;
		try {
			status = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
		return status;
	}

	@Override
	public void actionANCC(CreditCardBean bean1) throws IBSException {
		//logger.info("entered into actionANCC method of CreditCardDaoImpl class");

		entityManager.persist(bean1);

	}

	@Override

	public void blockCreditCard(BigInteger creditCardNumber) throws IBSException {

		CreditCardBean cardBean = null;

		try {

			cardBean = entityManager.find(CreditCardBean.class, creditCardNumber);

			cardBean.setCardStatus("Blocked");

		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);

		}

	}

	@Override
	public void actionUpgradeCC(String queryId) throws IBSException {
		//logger.info("entered into actionUpgradeCC method of CreditCardDaoImpl class");
		BigInteger cardNum = null;
		String type = null;
		CreditCardBean cardBean = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery("select d from CaseIdBean d where d.caseIdTotal =:queryid", CaseIdBean.class);
			query.setParameter("queryid", queryId);
			CaseIdBean caseIdBean = query.getSingleResult();
			cardNum = caseIdBean.getCardNumber();
			type = caseIdBean.getDefineServiceRequest();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		try {
			cardBean = entityManager.find(CreditCardBean.class, cardNum);
		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
		cardBean.setCardType(type);

	}

	@Override
	public List<CreditCardBean> viewAllUnblockedCreditCards() throws IBSException {
		List<CreditCardBean> unblockedCards = null;
		try {
			TypedQuery<CreditCardBean> creditQuery = entityManager.createQuery(SqlQueries.SELECT_FROM_CREDIT_CARDS,
					CreditCardBean.class);
			creditQuery.setParameter("num", "Active");
			unblockedCards = creditQuery.getResultList();
			if (unblockedCards.isEmpty())
				throw new IBSException("ALL cards are Blocked!");
		} catch (NullPointerException e) {

			throw new IBSException("ALL cards Blocked.");
		}

		return unblockedCards;
	}

	@Override

	public void activateCreditCard(BigInteger creditCardNumber) throws IBSException {

		CreditCardBean cardBean = null;

		try {

			cardBean = entityManager.find(CreditCardBean.class, creditCardNumber);

			cardBean.setCardStatus("Active");

		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);

		}

	}

	@Override

	public void deactivateCreditCard(BigInteger creditCardNumber) throws IBSException {

		CreditCardBean cardBean = null;

		try {

			cardBean = entityManager.find(CreditCardBean.class, creditCardNumber);

			cardBean.setCardStatus("Inactive");

		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);

		}

	}

	@Override
	public List<CreditCardBean> viewAllInactiveCreditCards() throws IBSException {
		List<CreditCardBean> unblockedCards = null;
		try {
			TypedQuery<CreditCardBean> creditQuery = entityManager.createQuery(SqlQueries.SELECT_FROM_CREDIT_CARDS,
					CreditCardBean.class);
			creditQuery.setParameter("num", "Inactive");
			unblockedCards = creditQuery.getResultList();
			if (unblockedCards.isEmpty())
				throw new IBSException("ALL cards are active!");
		} catch (NoResultException e) {

			throw new IBSException("ALL cards are active.");
		}

		return unblockedCards;
	}

}
