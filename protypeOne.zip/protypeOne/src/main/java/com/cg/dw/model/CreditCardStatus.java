package com.cg.dw.model;

public enum CreditCardStatus {

		 APPROVED, DECLINED, PENDING, BLOCKED
		
}
