package com.cg.dw.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.DebitCardBean;
import com.cg.dw.model.DebitCardTransaction;
import com.cg.dw.service.DebitCustomer;
import com.cg.dw.service.DebitCustomerVerification;

@Controller
@Scope("session")
public class DebitCardController {
	BigInteger cardNumber;
	BigInteger debitCard;
	@Autowired
	private DebitCustomer debitService;
	@Autowired
	private DebitCustomerVerification debitVerify;
	List<DebitCardTransaction> bean1;
	DebitCardBean debitBean = new DebitCardBean();
	
	@RequestMapping(value = "/debitlist", method = RequestMethod.GET)
    public ModelAndView list() {
        List<DebitCardBean> debitCardBeans;
        try {
            debitCardBeans = debitService.viewAllDebitCards();
        } catch (IBSException e) {
            String message = e.getMessage();
            return new ModelAndView("errorPage", "errorMessage", message);
        }
        return new ModelAndView("listDebitCards", "output", debitCardBeans);
    }
	
	@RequestMapping("/cards")
	public ModelAndView showCardHome() {
		return new ModelAndView("cardsHomePage");
	}

	@RequestMapping("/carddisplaymenu")
	public ModelAndView showCardsMenu(@RequestParam("debitCards") BigInteger debitCard) {
		this.cardNumber = debitCard;
		try {
			debitBean = debitService.fetchDebitdetails(debitCard);
		} catch (IBSException e) {
		}
		return new ModelAndView("cardsDetailsPage", "db", debitBean);
	}
	
	@RequestMapping("/cardMainMenu")
	public String showMenu() {
		return "cardsMenuPage";
	}
	
	@RequestMapping("/cardSubMenu")
	public String showCardMenu() {
		return "cardsSubMenuPage";
	}

	@RequestMapping(value = "/block", method = RequestMethod.GET)
	public ModelAndView block() {
		String output = "";
		debitCard = this.cardNumber;
		
		
		try {
			if(!debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Blocked")){
			debitService.requestDebitCardLost(debitCard);
			output = " Your card has been  Blocked.Contact branch for further process";
			}
			else{
				output="Your card is already blocked.";
				
			}
			return new ModelAndView("outputPage","output",output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage","output",output);
		}
	}

	@RequestMapping(value = "/activate", method = RequestMethod.GET)
	public ModelAndView activate() {
		String output = "";
		try{
		if(debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Inactive")){
			return new ModelAndView("activateCardPage");
	}
	
	else{
		output="Can not be activated";
		return new ModelAndView("outputPage", "output", output);
	}
		}catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}	
	}

	@RequestMapping(value = "/activate", method = RequestMethod.POST)
	public ModelAndView activate(@RequestParam("pin") String pin) {
		String output = "";
		debitCard = this.cardNumber;
		try {
			
			if (debitVerify.verifyDebitPin(pin, debitCard)) {
				debitService.activateDebitCard(debitCard);
				output = "Card successfully activated!";
			} else {
				output = "Incorrect Pin entered";
			}
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
		
	@RequestMapping(value = "/deactivate", method = RequestMethod.GET)
	public ModelAndView deactivate() {
		String output = "";
		try{
		if(debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Active")){
			return new ModelAndView("deactivateCardPage");
	}
	
	else{
		output="Can not be deactivated";
		return new ModelAndView("outputPage", "output", output);
	}
		}catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}	
	}
	
	@RequestMapping(value = "/deactivate", method = RequestMethod.POST)
	public ModelAndView deactivate(@RequestParam("pin") String pin) {
		String output = "";
		debitCard = this.cardNumber;
		try {
			
			if (debitVerify.verifyDebitPin(pin, debitCard)) {

				debitService.deactivateDebitCard(debitCard);
				output = "Card successfully deactivated!";
			} else {
				output = "Incorrect Pin entered";
			}
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

	@RequestMapping(value = "/reset", method = RequestMethod.GET)
	public ModelAndView resetPin() {
		String output = "";
		try{
			if(!debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Blocked") && !debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Inactive") ){
			return new ModelAndView("resetDebitPinPage");
	}
	
	else{
		output="You can not change pin of a blocked/inactive card";
		return new ModelAndView("outputPage", "output", output);
	}
		}catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}	
	}
	@RequestMapping(value = "/reset", method = RequestMethod.POST)
	public ModelAndView resetPin(@RequestParam("pin") String pin) {
		String output = "";
		debitCard = this.cardNumber;
		try {
			
			if (debitVerify.verifyDebitPin(pin, debitCard)) {
				return new ModelAndView("NewDebitPinPage");
			} else {
				output = "Incorrect Pin entered";
				return new ModelAndView("outputPage", "output", output);
			}
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
	@RequestMapping(value = "/resetpin", method = RequestMethod.POST)
	public ModelAndView resetPin2(@RequestParam("newpin") String newpin, @RequestParam("newpin2") String newpin2) {
		String output = "";
		debitCard = this.cardNumber;
		try {
			if (newpin2.equals(newpin)) {
				debitService.resetDebitPin(debitCard, newpin);
				output = "PIN SUCCESSFULLY CHANGED";
			} else {
				output = "PINS DO NOT MATCH...TRY AGAIN";
			}
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

	@RequestMapping(value = "/upgrade", method = RequestMethod.GET)
	public ModelAndView upgradeDebitCard() {
		String output = "";
		String type = null;
		debitCard = this.cardNumber;
		try {
			if(!debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Blocked") && !debitService.getDebitcardStatus(debitCard).equalsIgnoreCase("Inactive")){
			type = debitService.getDebitcardType(debitCard);
			if (type.equalsIgnoreCase("Silver")) {
				return new ModelAndView("upgradeDebitSilver");
			} else if (type.equalsIgnoreCase("Gold")) {
				return new ModelAndView("upgradeDebitGold");
			} else {
				output = "You already have a Platinum card.Can not upgrade further";
				return new ModelAndView("outputPage", "output", output);
			}}
			else{
				output="You can not upgrade a blocked/inactive card";
				return new ModelAndView("outputPage", "output", output);
			}
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}

	}
	@RequestMapping(value = "/upgradeTwo", method = RequestMethod.POST)
	public ModelAndView upgradeFromSilver(@RequestParam("type") String type, @RequestParam("remarks") String remarks) {
		String output = "";
		debitCard = this.cardNumber;
		try {
			String num = debitService.requestDebitCardUpgrade(debitCard, type, remarks);
			output = "Ticket Raised successfully. Your reference Id is" + num;
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
	@RequestMapping(value = "/upgradePlat", method = RequestMethod.POST)
	public ModelAndView upgradeFromGold(@RequestParam("type") String type, @RequestParam("remarks") String remarks) {
		String output = "";
		debitCard = this.cardNumber;
		try {
			String num = debitService.requestDebitCardUpgrade(debitCard, type, remarks);
			output = "Ticket Raised successfully. Your reference Id is" + num;
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

	@RequestMapping(value = "/requestStat", method = RequestMethod.GET)
	public String show() {
		return "statementDebitPage";
	}

	@RequestMapping(value = "/requestStat", method = RequestMethod.POST)
	public ModelAndView requestStatement(@RequestParam("fromdate") String fromdate,
			@RequestParam("enddate") String enddate) {
		String output = "";
		DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE;
		debitCard = this.cardNumber;
		try {
			LocalDate startDate1 = LocalDate.parse(fromdate, formatter);
			LocalDate endDate1 = LocalDate.parse(enddate, formatter);
			bean1 = debitService.getDebitTransactions(startDate1, endDate1, debitCard);
			System.out.println(bean1);
			return new ModelAndView("listDebitTransaction", "output", bean1);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
	
	@RequestMapping(value = "/applyDebit", method = RequestMethod.GET )
	public String applyDebitCard () {
		return "applyNewDebit";
	}
	
	@RequestMapping(value = "/applyDebit", method = RequestMethod.POST )
	public ModelAndView debitCard (@RequestParam ("accNum")BigInteger accountNumber, @RequestParam ("type")String newCardType, @RequestParam ("remarks")String remarks) {
		System.out.println(" " +accountNumber+ " " +newCardType+ " "  +remarks);
		String refId;
		String output = "";
		try {
			refId = debitService.applyNewDebitCard(accountNumber, newCardType, remarks);
			output ="Ticket Raised successfully. Your reference Id is" + refId; 
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
		

		
	}

}
