
package com.cg.dw.dao;

import java.math.BigInteger;

import com.cg.dw.exception.IBSException;

public interface CustomerDao {

	boolean verifyUCI(BigInteger uci) throws IBSException;

	String getNewName(BigInteger account) throws IBSException;

}
