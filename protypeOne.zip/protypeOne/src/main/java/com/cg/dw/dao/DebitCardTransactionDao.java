package com.cg.dw.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.DebitCardTransaction;

public interface DebitCardTransactionDao {
	//List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber) throws IBSException;

	

	BigInteger getDebitCardNumber(BigInteger transactionId) throws IBSException;

	BigInteger getDMUci(BigInteger transactionId) throws IBSException;

	boolean verifyDebitTransactionId(BigInteger transactionId) throws IBSException;



	BigInteger getDebitMismatchTranscId(String queryId) throws IBSException;



	List<DebitCardTransaction> getDebitMismatchTransc(BigInteger mismatchTransactionId) throws IBSException;



	List<DebitCardTransaction> getDebitTrans(LocalDate startDate, LocalDate endDate, BigInteger debitCardNumber) throws IBSException;

	boolean checkTransactions(BigInteger debitCardNumber) throws IBSException;
}
