package com.cg.dw.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.AccountBean;
import com.cg.dw.model.DebitCardBean;

public interface DebitCardDao {
	boolean verifyDebitCardNumber(BigInteger debitCardNumber) throws IBSException;

	String getDebitCardStatus(BigInteger debitCardNumber) throws IBSException;

	String getDebitCardPin(BigInteger debitCardNumber) throws IBSException;

	public void setNewDebitPin(BigInteger debitCardNumber, String pin) throws IBSException;

	String getdebitCardType(BigInteger debitCardNumber) throws IBSException;

	List<DebitCardBean> viewAllDebitCards() throws IBSException;

	void actionUpgradeDC(String queryId) throws IBSException;

	void actionANDC(DebitCardBean bean) throws IBSException;

	BigInteger getDMAccountNumber(BigInteger debitCardNumber) throws IBSException;

	//void actionBlockDC(String queryId, String status) throws IBSException;
	BigInteger getAccountNumber(BigInteger debitCardNumber) throws IBSException;

	void blockDebitCard(BigInteger debitCardNumber) throws IBSException;

	List<DebitCardBean> viewAllUnblockedDebitCards() throws IBSException;

	List<AccountBean> getAccountList() throws IBSException;

	//void activateDebitCard(BigInteger debitCardNumber) throws IBSException;

	void deactivateDebitCard(BigInteger debitCardNumber) throws IBSException;

	List<DebitCardBean> viewAllInactiveDebitCards() throws IBSException;

	void activateDebitCard(BigInteger debitCardNumber) throws IBSException;

	List<DebitCardBean> viewAllActiveCards()throws IBSException;

	DebitCardBean getDebitdetails(BigInteger debitCardNumber)throws IBSException ;


}
